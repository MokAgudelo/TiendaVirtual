package com.mintic.tienda.repositories;

import org.springframework.data.repository.CrudRepository;

import com.mintic.tienda.entities.Venta;

public interface IVenta  extends CrudRepository<Venta,Long> {

}
