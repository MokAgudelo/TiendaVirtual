package com.mintic.tienda.repositories;

import org.springframework.data.repository.CrudRepository;

import com.mintic.tienda.entities.DetalleVenta;

public interface IDetalleVenta   extends CrudRepository <DetalleVenta,Long>{

}
