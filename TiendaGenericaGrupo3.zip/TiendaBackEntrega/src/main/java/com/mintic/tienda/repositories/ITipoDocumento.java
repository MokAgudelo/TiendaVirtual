package com.mintic.tienda.repositories;

import org.springframework.data.repository.CrudRepository;

import com.mintic.tienda.entities.TipoDocumento;

public interface ITipoDocumento extends CrudRepository<TipoDocumento,Long> {

}
