package com.mintic.tiendafront;

import javax.validation.Valid;

import org.apache.jasper.tagplugins.jstl.core.If;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.mintic.tiendafront.client.IClientTienda;
import com.mintic.tiendafront.client.IProveedor;
import com.mintic.tiendafront.dto.Proveedor;
import com.mintic.tiendafront.dto.ProveedorNit;
import ch.qos.logback.core.joran.conditional.ElseAction;


@Controller
public class ControladorProveedor {

	@Autowired
	IProveedor iproveedor;
	
	
	@GetMapping("/proveedor")
	public String proveedor(Model model) {
		
	model.addAttribute("proveedor", iproveedor.getProveedor());
		return "proveedor";
	}
	
	@GetMapping("/proveedorConsulta")
	public String proveedorConsulta(Model model) {
		
	//model.addAttribute("proveedor", iproveedor.getProveedor());
		return "proveedorConsulta";
	}
	
	@PostMapping("/proveedorNit")
	public String proveedorNit(Model model, @ModelAttribute ProveedorNit parametro) {

		if (parametro.getNit().length() > 0) {
			
					try 
					{
						Proveedor proveedor= iproveedor.buscarProveedorNit(parametro);
						System.out.println("-----"+proveedor.getNombre());
						model.addAttribute("proveedor", proveedor);
				
					} catch (Exception e) {
						
						model.addAttribute("message", "Nit no existe");
						
					}
				} 
		else {
			model.addAttribute("proveedor",iproveedor.getProveedor());
		}

		return "proveedorConsulta";
	}

	@GetMapping("/proveedorNuevo")
	public String proveedorNuevo(Model model) {

		model.addAttribute("proveedorEditar", new Proveedor());
		model.addAttribute("proveedor", new Proveedor());
		

		return "proveedorNuevo";
	}

	@PostMapping("/proveedorActualizar")
	public String proveedorActualizar(Model model, @Valid @ModelAttribute Proveedor proveedor, BindingResult result) {

		model.addAttribute("proveedorEditar", new Proveedor());
		

		if (result.hasErrors()) {

			model.addAttribute("message", "Error en la Actualización");
			return "proveedorActualizar";
		}

		iproveedor.nuevoProveedor(proveedor);
		//model.addAttribute("proveedor",iproveedor.getProveedor());
		model.addAttribute("message", "Actualización de Proveedor correcta");
		
		return "proveedorConsulta";
	}
	
	
	@PostMapping("/proveedorNuevo")
	public String proveedorCrear(Model model, @Valid @ModelAttribute Proveedor proveedor, BindingResult result) {

		model.addAttribute("proveedorEditar", new Proveedor());
		

		if (result.hasErrors()) {

			return "proveedorNuevo";
		}

		iproveedor.nuevoProveedor(proveedor);
		model.addAttribute("proveedor",iproveedor.getProveedor());
		model.addAttribute("message", "Creación de Proveedor correcta");
		return "proveedorNuevo";
	}
	
	
	@GetMapping("/proveedor/{id}")
	public String actualizarUsuario(Model model, @PathVariable(name = "id") Long id) {
		model.addAttribute("proveedor", new Proveedor());
		Proveedor proveedorEditar = iproveedor.buscarProveedor(id);
		model.addAttribute("proveedorEditar", proveedorEditar);
		return "proveedorActualizar";
	}

	@GetMapping("/eliminarProveedor/{id}")
	public String eliminarProveedor(Model model, @PathVariable(name = "id") Long id) {
		iproveedor.borrarProveedor(id);
		model.addAttribute("proveedor",iproveedor.getProveedor());
		model.addAttribute("message", "Eliminación de Proveedor correcto");
		return "proveedor";
	}

	
	
	
}