package com.mintic.tiendafront.dto;

public class ClienteDocumento {
	private String numeroDocumento;
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	

   }
