package com.mintic.tiendafront.dto;

public class UsuarioDocumento {
	private String numeroDocumento;
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	

   }
