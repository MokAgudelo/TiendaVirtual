package com.mintic.tiendafront.dto;

public class ProveedorNit {
	private String nit;

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}
	
	
	

}