package com.mintic.tiendafront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TiendaFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(TiendaFrontApplication.class, args);
	}

}
