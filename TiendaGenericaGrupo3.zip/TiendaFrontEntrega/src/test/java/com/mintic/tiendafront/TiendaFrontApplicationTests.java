package com.mintic.tiendafront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaFrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
